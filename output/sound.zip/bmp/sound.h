#ifndef SOUND_H
#define SOUND_H

void play_sound(int row, int col);

#endif
